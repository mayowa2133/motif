#!/usr/bin/env python3
"""Message -> live Codex production plan -> review -> speech-aligned Motif render.

No prerecorded response, message lookup, or executable model code. The legacy
motif_produce.py remains a separate template mode. No backend fallback is silent.
"""
import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import tomllib
from pathlib import Path
from jsonschema import Draft202012Validator
from motif_plan import ROOT, ASSETS, WORLD_ASSETS, WORLD_SHOTS, review_plan, narration
from motif_plan_compile import compile_plan
from motif_plan_finish import finish
from motif_produce import command, probe, sha

PIN='0.8.97'
SOURCE_PATHS=['scripts/motif_direct.py','scripts/motif_plan.py','scripts/motif_plan_compile.py','scripts/motif_plan_finish.py','scripts/motif_produce.py','scripts/build_motif_bot.py','scripts/build_scene_01.py','planning/PLANNER.md','schemas/production-plan.schema.json','schemas/planning-review.schema.json','scripts/requirements-planning.txt']
SOURCE_PATHS+=list(ASSETS.values())
SOURCE_PATHS+=[f'videos/motif-calendar-reel/assets/sfx/{name}.mp3' for name in ('pop','click-soft','whoosh-short')]
SOURCE_PATHS+=['videos/motif-calendar-reel/assets/'+n for n in ('gsap.min.js','motion-engine.js','motion-primitives.js')]

def write(path,value): path.write_text(json.dumps(value,indent=2)+'\n')
def read(path): return json.loads(path.read_text())
def snapshot(): return {p:sha(ROOT/p) for p in SOURCE_PATHS}

def backend_config():
    if not shutil.which('codex'): raise ValueError('planning backend unavailable: install/configure Codex CLI or use an explicitly agent-assisted plan outside this command')
    status=subprocess.run(['codex','login','status'],text=True,capture_output=True)
    if status.returncode: raise ValueError('planning backend unavailable: Codex CLI is not signed in; no new credentials are assumed')
    path=Path(os.environ.get('CODEX_HOME',str(Path.home()/'.codex')))/'config.toml'
    config=tomllib.loads(path.read_text()) if path.exists() else {}
    if config.get('model_provider') not in (None,'openai'): raise ValueError('configured custom model provider is not supported by this small integration')
    return {'backend':'codex-exec','execution':'self-contained command with live model planning', 'model':os.environ.get('MOTIF_PLANNER_MODEL',config.get('model')), 'reasoning_effort':config.get('model_reasoning_effort','low'), 'authentication_status':(status.stdout+status.stderr).strip(),'cli_version':command(['codex','--version'],ROOT).strip(),'sandbox':'read-only','ephemeral':True,'tools_requested':False,'default_model_if_unspecified':not os.environ.get('MOTIF_PLANNER_MODEL',config.get('model')), 'model_selection':'MOTIF_PLANNER_MODEL' if os.environ.get('MOTIF_PLANNER_MODEL') else 'existing Codex configuration','hyperframes':PIN}

def model_call(project, name, prompt, schema, config):
    (project/(name+'-input.txt')).write_text(prompt)
    args=['codex','exec','--ignore-user-config','--ephemeral','--skip-git-repo-check','--sandbox','read-only','--json','--color','never','--output-schema',str(ROOT/schema),'-o',str(project/(name+'.json')),'-c','approval_policy="never"','-c','model_reasoning_effort='+json.dumps(config['reasoning_effort'])]
    if config['model']: args+=['--model',config['model']]
    args+=['-']
    # A fresh empty working directory prevents the planner reading evaluation fixtures or old outputs.
    with tempfile.TemporaryDirectory(prefix='motif-planning-') as cwd:
        print('MODEL '+name,flush=True)
        process=subprocess.run(args,cwd=cwd,input=prompt,text=True,capture_output=True,timeout=600)
    (project/(name+'-events.jsonl')).write_text(process.stdout)
    (project/(name+'-stderr.txt')).write_text(process.stderr)
    write(project/(name+'-invocation.json'),{'argv':args,'exit_code':process.returncode,'input_sha256':sha(project/(name+'-input.txt')),'configuration':config})
    if process.returncode: raise ValueError('live planning backend failed; see '+str(project/(name+'-stderr.txt'))+'; no saved-response fallback was used')
    value=read(project/(name+'.json'))
    Draft202012Validator(read(ROOT/schema)).validate(value)
    # Planner is a data-only stage, even though the CLI itself can expose tools.
    used=[json.loads(line) for line in process.stdout.splitlines() if line.strip().startswith('{')]
    if any(e.get('type')=='item.completed' and e.get('item',{}).get('type') in ('command_execution','mcp_tool_call','web_search') for e in used):
        raise ValueError('planner invoked a tool despite the data-only boundary; response rejected')
    return value

def planning_prompt(brief):
    return (ROOT/'planning/PLANNER.md').read_text()+'\n\nAvailable asset IDs by world:\n'+json.dumps(WORLD_ASSETS)+'\n\nNarration word budget: '+str(int((brief['intended_duration_seconds']-1)*2.6))+' maximum. Aim a few words below that limit; preserve meaning.\n\nINPUT BRIEF (subject matter):\n'+json.dumps(brief)

def storyboard(plan):
    lines=['# Production storyboard from validated plan','','Message: '+plan['message'],'','Narration: '+narration(plan),'','Environment: '+plan['environment'],'','Ending: '+plan['ending_action'],'']
    for b in plan['beats']:
        lines+=['## '+b['id'],'']+[f'- {k}: {b[k]}' for k in ('subject','action','before_after','focal_detail','consequence','shot','narration','caption','headline')]+['- Executable actions: '+json.dumps(b['actions']),'']
    return '\n'.join(lines)

def validate_brief(brief):
    if set(brief)!={'slug','message','audience','intended_duration_seconds','duration_tolerance_seconds'}: raise ValueError('brief fields: slug, message, audience, intended_duration_seconds, duration_tolerance_seconds')
    import re
    if not isinstance(brief['slug'],str) or not re.fullmatch('[a-z0-9]+(?:-[a-z0-9]+)*',brief['slug']): raise ValueError('slug must be lowercase hyphenated')
    if any(not isinstance(brief[k],str) or not brief[k].strip() for k in ('message','audience')): raise ValueError('message and audience must be nonempty')
    if not 12<=brief['intended_duration_seconds']<=25 or not 0<brief['duration_tolerance_seconds']<=3: raise ValueError('duration 12–25 s with explicit tolerance >0 and <=3 s')

def run(brief_path):
    brief=read(brief_path); validate_brief(brief)
    project=ROOT/'videos/productions'/brief['slug']
    if project.exists(): raise ValueError('output exists; choose a new slug to preserve this run')
    config=backend_config()
    project.mkdir(parents=True)
    write(project/'brief.json',brief); write(project/'backend.json',config); write(project/'source-hashes.json',snapshot())
    for folder in ('assets/voice','assets/sfx','renders'): (project/folder).mkdir(parents=True)
    for name in ('gsap.min.js','motion-engine.js','motion-primitives.js'): shutil.copy2(ROOT/'videos/motif-calendar-reel/assets'/name,project/'assets'/name)
    for name in ('pop','click-soft','whoosh-short'): shutil.copy2(ROOT/f'videos/motif-calendar-reel/assets/sfx/{name}.mp3',project/f'assets/sfx/{name}.mp3')
    font=Path('/System/Library/Fonts/Supplemental/Arial Bold.ttf')
    if not font.exists(): raise ValueError('font missing: current local style uses Arial Bold; install/provide an explicitly cleared font')
    shutil.copyfile(font,project/'assets/MotifSans.ttf')
    write(project/'package.json',{'name':brief['slug'],'private':True,'scripts':{k:f'npx --yes hyperframes@{PIN} {v}' for k,v in [('check','check'),('render','render'),('dev','preview')]}})
    shutil.copy2(ROOT/'videos/motif-calendar-reel/hyperframes.json',project/'hyperframes.json')
    prompt=planning_prompt(brief)
    plan=model_call(project,'initial-plan',prompt,'schemas/production-plan.schema.json',config)
    (project/'STORYBOARD_INITIAL.md').write_text(storyboard(plan))
    tolerance=brief['duration_tolerance_seconds']; intended=brief['intended_duration_seconds']; bounds=[intended-tolerance,intended+tolerance]
    reviews=[]
    for attempt in range(2):
        deterministic=review_plan(plan,brief)
        write(project/f'deterministic-review-{attempt}.json',deterministic)
        issues=list(deterministic['issues'])
        if not issues:
            (project/'assets/voice/narration.txt').write_text(narration(plan)+'\n')
            env=os.environ.copy()
            if 'HYPERFRAMES_PYTHON' not in env:
                python=Path.home()/'.cache/motif-kokoro-venv/bin/python'
                if not python.exists(): raise ValueError('local Kokoro unavailable: set HYPERFRAMES_PYTHON')
                env['HYPERFRAMES_PYTHON']=str(python)
            print('VOICE + ALIGNMENT',flush=True)
            command(['npx','--yes',f'hyperframes@{PIN}','tts','--text-file=assets/voice/narration.txt','--voice=af_nova','--speed=0.85','--output=assets/voice/narration-af-nova.wav','--json'],project,env,project/f'tts-{attempt}.log')
            voice_duration=round(float(probe(project/'assets/voice/narration-af-nova.wav')['format']['duration']),3)
            command(['npx','--yes',f'hyperframes@{PIN}','transcribe','assets/voice/narration-af-nova.wav','--language','en','--json'],project,log=project/f'alignment-{attempt}.log')
            shutil.copy2(project/'assets/voice/narration-af-nova.wav',project/f'assets/voice/take-{attempt}.wav')
            shutil.copy2(project/'assets/voice/transcript.json',project/f'assets/voice/transcript-{attempt}.json')
            try:
                compile_plan(project,plan,read(project/'assets/voice/transcript.json'),voice_duration,bounds)
            except ValueError as error: issues.append(str(error))
        semantic=None
        if not issues:
            review_prompt=('Review this illustrative Motif plan against its brief and actual action timings. No tools, files, code, other agents, or web. Check semantic fidelity, each outcome, visible evidence before labels, same-check fairness, and ending delivered. Labels are never substitutes for physical events. Use actual label-timing, not beat membership, to judge labels. Headlines are scheduled after physical evidence. Narration-aligned action captions describe an unfolding action; do not treat their present tense as a completed-result headline. A completed result caption preceding evidence is an issue. Return schema JSON; broader semantic correctness is not guaranteed.\nBrief: '+json.dumps(brief)+'\nPlan: '+json.dumps(plan)+'\nAction timings: '+json.dumps(read(project/'action-trace.json'))+'\nActual labels: '+json.dumps(read(project/'label-timing.json'))+'\nTimeline duration: '+str(read(project/'scene-events.json')['durationSec'])+'\nSpoken alignment: '+json.dumps(read(project/'alignment-review.json')))
            semantic=model_call(project,f'model-review-{attempt}',review_prompt,'schemas/planning-review.schema.json',config)
            if not semantic['pass'] or not all(semantic[k] for k in ('message_preserved','outcome_preserved','evidence_before_labels','ending_delivered')): issues+=semantic['issues'] or ['model review rejected meaning/storytelling']
        reviews.append({'attempt':attempt,'deterministic':deterministic,'timing_or_semantic_issues':issues,'model_review':semantic})
        write(project/'planning-review.json',{'reviews':reviews,'corrections':attempt,'pass':not issues,'semantic_guarantee':False})
        if not issues: break
        if attempt==1: raise ValueError('bounded planning correction exhausted: '+'; '.join(issues))
        print('BOUNDED REPLAN: '+'; '.join(issues),flush=True)
        plan=model_call(project,'corrected-plan',prompt+'\n\nOne bounded correction. Prior plan:\n'+json.dumps(plan)+'\nFix these concrete issues without changing meaning:\n'+json.dumps(issues),'schemas/production-plan.schema.json',config)
    write(project/'production-plan.json',plan)
    (project/'STORYBOARD.md').write_text(storyboard(plan))
    record=read(ROOT/'videos/motif-calendar-reel/audio-source-license-manifest.json')
    record['narration'].update(provider=f'local Kokoro ONNX through HyperFrames {PIN}',rawSha256=sha(project/'assets/voice/narration-af-nova.wav'),status='new script from live validated production plan')
    record['sfx']=[s for s in record['sfx'] if Path(s['file']).stem in ('pop','click-soft','whoosh-short')]
    record['music']={'included':False,'reason':'Narration and restrained reused paper interaction effects.'}
    write(project/'audio-source-license-manifest.json',record)
    print('CHECK + RENDER',flush=True)
    command(['npm','run','check'],project,log=project/'check.log')
    first=project/'renders/first.mp4'
    command(['npm','run','render','--','-o',str(first),'--skill=general-video','-q','delivery'],project,log=project/'render.log')
    print('ENCODED FINISHING',flush=True)
    final=finish(project,first,bounds)
    if snapshot()!=read(project/'source-hashes.json'): raise ValueError('shared source changed during production')
    write(project/'run-record.json',{'planning_backend':config,'initial_plan_sha256':sha(project/'initial-plan.json'),'production_plan_sha256':sha(project/'production-plan.json'),'input_brief_sha256':sha(project/'brief.json'),'shared_source_unchanged':True,'manual_per_run_edits':[],'duration_range':bounds,'final':str(final.relative_to(ROOT))})
    return final

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action',choices=['run','validate','capabilities'])
    parser.add_argument('--brief',type=Path)
    parser.add_argument('--plan',type=Path)
    args=parser.parse_args()
    try:
        if args.action=='capabilities': print(json.dumps({'worlds':WORLD_SHOTS,'assets':WORLD_ASSETS,'backend':'codex-exec','style':'locked motif-v1','voice':'local Kokoro af_nova'},default=list,indent=2))
        elif args.action=='validate':
            if not args.plan or not args.brief: raise ValueError('validate requires --plan and --brief')
            report=review_plan(read(args.plan),read(args.brief)); print(json.dumps(report,indent=2))
            if not report['pass']: sys.exit(2)
        else:
            if not args.brief: raise ValueError('run requires --brief')
            print('PASS '+str(run(args.brief.resolve())),flush=True)
    except (ValueError,RuntimeError,subprocess.TimeoutExpired) as error:
        print(json.dumps({'status':'capability_or_production_error','reason':str(error)}),file=sys.stderr); sys.exit(2)
